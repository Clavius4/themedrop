﻿#!/usr/bin/env bash
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
WALL_DEST="$HOME/Library/Desktop Pictures/Breaking Bad"
echo ""
echo "  Breaking Bad — macOS Theme Installer"
echo "  ─────────────────────────────────────"
echo "[1/3] Installing wallpapers..."
mkdir -p "$WALL_DEST"
cp -f "$SCRIPT_DIR/wallpapers/"*.jpg "$WALL_DEST/"
echo "      OK ($(ls "$WALL_DEST"/*.jpg | wc -l | tr -d ' ') wallpapers)"
echo "[2/3] Applying wallpaper..."
osascript <<APPLESCRIPT 2>/dev/null && echo "      OK" || echo "      (set manually in System Settings)"
tell application "System Events"
    set theDesktops to every desktop
    repeat with aDesktop in theDesktops
        set picture of aDesktop to "$WALL_DEST/1.jpg"
    end repeat
end tell
APPLESCRIPT
echo "[3/3] Enabling Dark Mode..."
osascript -e 'tell application "System Events" to tell appearance preferences to set dark mode to true' 2>/dev/null && echo "      OK" || true
echo ""
echo "  Done! For slideshow: System Settings → Wallpaper → Add Folder → $WALL_DEST"
echo "  Say my name."
