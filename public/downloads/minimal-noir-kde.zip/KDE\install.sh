﻿#!/usr/bin/env bash
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
WALL_DEST="$HOME/.local/share/wallpapers/Minimal Noir"
echo ""
echo "  Minimal Noir — KDE Plasma Theme Installer"
echo "  ─────────────────────────────────────"
echo "[1/2] Installing wallpapers..."
mkdir -p "$WALL_DEST"
cp -f "$SCRIPT_DIR/wallpapers/"*.jpg "$WALL_DEST/"
echo "      OK"
echo "[2/2] Applying wallpaper via qdbus..."
qdbus org.kde.plasmashell /PlasmaShell org.kde.PlasmaShell.evaluateScript \
  "var d=desktops()[0];d.wallpaperPlugin='org.kde.image';d.currentConfigGroup=['Wallpaper','org.kde.image','General'];d.writeConfig('Image','file://$WALL_DEST/1.jpg');" 2>/dev/null \
  && echo "      OK" || echo "      (set manually: right-click desktop → Configure)"
echo ""
echo "  Done! Wallpapers at $WALL_DEST"
echo "  Less is more."
