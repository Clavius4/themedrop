﻿# Minimal Noir — Cross-Platform Theme Pack

> *"Less is more."*

10 HD wallpapers + one-click installers for Windows, macOS, GNOME, and KDE.

## Install

| Platform | Command |
|---|---|
| Windows | Double-click \$name.deskthemepack\ |
| macOS | \chmod +x install.sh && ./install.sh\ |
| Ubuntu/GNOME | \chmod +x install.sh && ./install.sh\ |
| KDE Plasma | \chmod +x install.sh && ./install.sh\ |

## Contents
- 10 HD wallpapers (1080p+)
- Dark mode enabled automatically
- Accent colour: \$(System.Collections.Hashtable.color)\

## Credits
Wallpapers from [wallpapercave.com](https://wallpapercave.com) — personal/non-commercial use.
Fan creation. Not affiliated with Minimal Noir.
