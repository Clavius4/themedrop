﻿#!/usr/bin/env bash
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
WALL_DIR="$HOME/.themes/Minimal Noir/wallpapers"
echo ""
echo "  Minimal Noir — GNOME/Ubuntu Theme Installer"
echo "  ─────────────────────────────────────"
echo "[1/3] Installing wallpapers..."
mkdir -p "$WALL_DIR"
cp -f "$SCRIPT_DIR/wallpapers/"*.jpg "$WALL_DIR/"
echo "      OK"
echo "[2/3] Setting wallpaper..."
gsettings set org.gnome.desktop.background picture-uri "file://$WALL_DIR/1.jpg" 2>/dev/null || true
gsettings set org.gnome.desktop.background picture-uri-dark "file://$WALL_DIR/1.jpg" 2>/dev/null || true
echo "      OK"
echo "[3/3] Enabling Dark Mode..."
gsettings set org.gnome.desktop.interface color-scheme 'prefer-dark' 2>/dev/null && echo "      OK" || true
echo ""
echo "  Done! Wallpapers at $WALL_DIR"
echo "  Less is more."
