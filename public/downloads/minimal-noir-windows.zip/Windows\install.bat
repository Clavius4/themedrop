﻿@echo off
setlocal enabledelayedexpansion
echo.
echo  =========================================
echo   Minimal Noir Theme - Windows Installer
echo   Less is more.
echo  =========================================
echo.
echo [1/3] Applying theme...
start "" "%~dp0Minimal Noir.theme"
echo        OK - Theme dialog will open.
echo.
echo [2/3] Enabling Dark Mode...
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize" /v "AppsUseLightTheme" /t REG_DWORD /d 0 /f >nul 2>&1
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize" /v "SystemUsesLightTheme" /t REG_DWORD /d 0 /f >nul 2>&1
echo        OK
echo.
echo [3/3] Setting accent colour...
reg add "HKCU\Software\Microsoft\Windows\DWM" /v "AccentColor" /t REG_DWORD /d 0xFFF0F0F0 /f >nul 2>&1
echo        OK
echo.
echo  Installation complete!
pause
