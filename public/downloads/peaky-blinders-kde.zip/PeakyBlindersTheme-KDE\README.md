# Peaky Blinders — KDE Plasma Theme Pack

> *"By order of the Peaky Blinders."*

A full KDE Plasma personalisation pack: Global Theme with charcoal + amber/gold colour scheme,
10-image HD wallpaper set, and a complete `.colors` file for the Plasma colour engine.

---

## What's Included

| File / Folder | Purpose |
|---|---|
| `wallpapers/` | 10 HD Peaky Blinders wallpapers |
| `look-and-feel/com.peakyblinders.theme/` | Plasma Global Theme (Look and Feel) package |
| `install.sh` | One-command installer |
| `uninstall.sh` | Full reverter |

The installer also writes `PeakyBlinders.colors` to `~/.local/share/color-schemes/`
— a full 16-role KDE colour scheme with gold accents on deep charcoal.

---

## Compatibility

| Distro / DE | Status |
|---|---|
| Kali Linux (KDE edition) | Fully tested |
| Kubuntu 22.04 LTS | Fully tested |
| Kubuntu 24.04 LTS | Fully tested |
| KDE neon | Compatible |
| openSUSE Tumbleweed (KDE) | Compatible |
| Arch Linux + KDE | Compatible |
| Manjaro KDE | Compatible |
| Fedora KDE Spin | Compatible |

KDE Plasma version required: **5.24 or later** (Plasma 6 also supported).

---

## Installation

### Automatic

```bash
cd ~/Downloads/PeakyBlindersTheme-KDE
chmod +x install.sh
./install.sh
```

This will:
1. Install the Plasma Look and Feel package → `~/.local/share/plasma/look-and-feel/`
2. Copy wallpapers → `~/.local/share/wallpapers/PeakyBlinders/`
3. Write the colour scheme → `~/.local/share/color-schemes/PeakyBlinders.colors`
4. Apply the global theme via `lookandfeeltool`
5. Set wallpaper via `qdbus` / `plasma-apply-*`
6. Apply the colour scheme via `plasma-apply-colorscheme`

### Manual

#### 1. Install Look and Feel
```bash
mkdir -p ~/.local/share/plasma/look-and-feel/
cp -r look-and-feel/com.peakyblinders.theme \
      ~/.local/share/plasma/look-and-feel/
```

#### 2. Install wallpapers
```bash
mkdir -p ~/.local/share/wallpapers/PeakyBlinders
cp wallpapers/*.jpg ~/.local/share/wallpapers/PeakyBlinders/
```

#### 3. Apply via System Settings
- **System Settings → Global Theme** → select **Peaky Blinders** → Apply
- **System Settings → Colors** → select **Peaky Blinders** → Apply
- **System Settings → Wallpaper** → Add Folder → `~/.local/share/wallpapers/PeakyBlinders`

#### 4. Apply via command line
```bash
# Apply global theme
lookandfeeltool --apply com.peakyblinders.theme

# Apply colour scheme (Plasma 5.23+)
plasma-apply-colorscheme PeakyBlinders

# Set wallpaper
qdbus org.kde.plasmashell /PlasmaShell \
  org.kde.PlasmaShell.evaluateScript \
  "var d=desktops()[0]; d.wallpaperPlugin='org.kde.image'; \
   d.currentConfigGroup=['Wallpaper','org.kde.image','General']; \
   d.writeConfig('Image','file://$HOME/.local/share/wallpapers/PeakyBlinders/1.jpg');"
```

---

## Wallpaper Slideshow (KDE)

1. Right-click the desktop → **Configure Desktop and Wallpaper**
2. Wallpaper type → **Slideshow**
3. Add folder → `~/.local/share/wallpapers/PeakyBlinders`
4. Set interval (recommended: 30 min) and enable Shuffle

---

## Colour Scheme Reference

| Role | RGB | Notes |
|---|---|---|
| Window Background | `26, 22, 18` | Deep charcoal |
| View Background | `33, 29, 24` | Dark sepia |
| Normal Text | `200, 190, 168` | Warm grey |
| Active Text | `240, 192, 64` | Bright gold |
| Selection BG | `200, 160, 48` | Amber |
| Selection FG | `26, 22, 18` | Charcoal on gold |
| Link | `200, 160, 48` | Amber |
| Negative (error) | `192, 57, 43` | Brick red |
| Positive | `125, 158, 107` | Muted sage |

---

## Uninstall

```bash
chmod +x uninstall.sh && ./uninstall.sh
```

Restores the default **Breeze Dark** theme.

---

## Credits

Wallpapers from [wallpapercave.com](https://wallpapercave.com/peaky-blinders-wallpapers) — personal/non-commercial use.
Fan creation — not affiliated with the show's creators.
