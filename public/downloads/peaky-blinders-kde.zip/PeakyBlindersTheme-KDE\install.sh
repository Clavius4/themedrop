#!/usr/bin/env bash
# ============================================================
#  Peaky Blinders — KDE Plasma Theme Installer
#  Tested: KDE Plasma 5.27+ / Plasma 6
#          Kali Linux, Kubuntu 22.04/24.04, openSUSE, Arch
# ============================================================

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
THEME_ID="com.peakyblinders.theme"
LOOK_FEEL_SRC="$SCRIPT_DIR/look-and-feel/$THEME_ID"
LOOK_FEEL_DEST="$HOME/.local/share/plasma/look-and-feel/$THEME_ID"
WALL_DEST="$HOME/.local/share/wallpapers/PeakyBlinders"
COLOR_DEST="$HOME/.local/share/color-schemes"

GOLD='\033[0;33m'
GRN='\033[0;32m'
RED='\033[0;31m'
NC='\033[0m'

step() { echo -e "${GOLD}[ $1 ]${NC} $2"; }
ok()   { echo -e "       ${GRN}✓${NC} $1"; }
err()  { echo -e "       ${RED}✗${NC} $1 (continuing...)"; }

if [[ "$(uname)" != "Linux" ]]; then
  echo -e "${RED}Error:${NC} This installer is for Linux (KDE) only."
  exit 1
fi

echo ""
echo "  ██████╗ ███████╗ █████╗ ██╗  ██╗██╗   ██╗"
echo "  ██╔══██╗██╔════╝██╔══██╗██║ ██╔╝╚██╗ ██╔╝"
echo "  ██████╔╝█████╗  ███████║█████╔╝  ╚████╔╝ "
echo "  ██╔═══╝ ██╔══╝  ██╔══██║██╔═██╗   ╚██╔╝  "
echo "  ██║     ███████╗██║  ██║██║  ██╗   ██║   "
echo "  ╚═╝     ╚══════╝╚═╝  ╚═╝╚═╝  ╚═╝   ╚═╝   "
echo "       B L I N D E R S  —  KDE Plasma Theme"
echo "  ─────────────────────────────────────────"
echo ""

# ── Step 1: Install Look and Feel package ──────────────────────
step "1/5" "Installing Plasma Look and Feel package..."
mkdir -p "$LOOK_FEEL_DEST/contents"
cp -r "$LOOK_FEEL_SRC/"* "$LOOK_FEEL_DEST/"
ok "Look and Feel installed → $LOOK_FEEL_DEST"

# ── Step 2: Install wallpapers ─────────────────────────────────
step "2/5" "Installing wallpapers..."
mkdir -p "$WALL_DEST"
cp -f "$SCRIPT_DIR/wallpapers/"*.jpg "$WALL_DEST/"
WCOUNT=$(ls "$WALL_DEST"/*.jpg 2>/dev/null | wc -l)
ok "Copied $WCOUNT wallpapers → $WALL_DEST"

# ── Step 3: Install colour scheme ──────────────────────────────
step "3/5" "Installing Peaky Blinders colour scheme..."
mkdir -p "$COLOR_DEST"
cat > "$COLOR_DEST/PeakyBlinders.colors" << 'COLOREOF'
[ColorEffects:Disabled]
Color=56,56,56
ColorAmount=0
ColorEffect=0
ContrastAmount=0.65
ContrastEffect=1
IntensityAmount=0.1
IntensityEffect=2

[ColorEffects:Inactive]
ChangeSelectionColor=true
Color=112,111,110
ColorAmount=0.025
ColorEffect=2
ContrastAmount=0.1
ContrastEffect=2
Enable=false
IntensityAmount=0
IntensityEffect=0

[Colors:Button]
BackgroundAlternate=33,29,24
BackgroundNormal=33,29,24
DecorationFocus=200,160,48
DecorationHover=200,160,48
ForegroundActive=240,192,64
ForegroundInactive=120,110,90
ForegroundLink=200,160,48
ForegroundNegative=192,57,43
ForegroundNeutral=230,126,34
ForegroundNormal=200,169,110
ForegroundPositive=125,158,107
ForegroundVisited=140,100,160

[Colors:Complementary]
BackgroundAlternate=26,22,18
BackgroundNormal=26,22,18
DecorationFocus=200,160,48
DecorationHover=200,160,48
ForegroundActive=240,192,64
ForegroundInactive=100,90,70
ForegroundLink=200,160,48
ForegroundNegative=192,57,43
ForegroundNeutral=230,126,34
ForegroundNormal=200,190,168
ForegroundPositive=125,158,107
ForegroundVisited=140,100,160

[Colors:Header]
BackgroundAlternate=30,26,20
BackgroundNormal=26,22,18
DecorationFocus=200,160,48
DecorationHover=200,160,48
ForegroundActive=240,192,64
ForegroundInactive=100,90,70
ForegroundLink=200,160,48
ForegroundNegative=192,57,43
ForegroundNeutral=230,126,34
ForegroundNormal=200,169,110
ForegroundPositive=125,158,107
ForegroundVisited=140,100,160

[Colors:Selection]
BackgroundAlternate=168,130,30
BackgroundNormal=200,160,48
DecorationFocus=200,160,48
DecorationHover=200,160,48
ForegroundActive=26,22,18
ForegroundInactive=26,22,18
ForegroundLink=26,22,18
ForegroundNegative=192,57,43
ForegroundNeutral=230,126,34
ForegroundNormal=26,22,18
ForegroundPositive=125,158,107
ForegroundVisited=26,22,18

[Colors:Tooltip]
BackgroundAlternate=46,40,32
BackgroundNormal=46,40,32
DecorationFocus=200,160,48
DecorationHover=200,160,48
ForegroundActive=240,192,64
ForegroundInactive=120,110,90
ForegroundLink=200,160,48
ForegroundNegative=192,57,43
ForegroundNeutral=230,126,34
ForegroundNormal=240,192,64
ForegroundPositive=125,158,107
ForegroundVisited=140,100,160

[Colors:View]
BackgroundAlternate=26,22,18
BackgroundNormal=33,29,24
DecorationFocus=200,160,48
DecorationHover=200,160,48
ForegroundActive=240,192,64
ForegroundInactive=100,90,70
ForegroundLink=200,160,48
ForegroundNegative=192,57,43
ForegroundNeutral=230,126,34
ForegroundNormal=200,169,110
ForegroundPositive=125,158,107
ForegroundVisited=140,100,160

[Colors:Window]
BackgroundAlternate=30,26,20
BackgroundNormal=26,22,18
DecorationFocus=200,160,48
DecorationHover=200,160,48
ForegroundActive=240,192,64
ForegroundInactive=100,90,70
ForegroundLink=200,160,48
ForegroundNegative=192,57,43
ForegroundNeutral=230,126,34
ForegroundNormal=200,190,168
ForegroundPositive=125,158,107
ForegroundVisited=140,100,160

[General]
ColorScheme=PeakyBlinders
Name=Peaky Blinders
shadeSortColumn=true

[KDE]
contrast=4

[WM]
activeBackground=26,22,18
activeBlend=200,160,48
activeForeground=200,169,110
inactiveBackground=22,18,14
inactiveBlend=80,70,50
inactiveForeground=100,90,70
COLOREOF
ok "Colour scheme installed → $COLOR_DEST/PeakyBlinders.colors"

# ── Step 4: Apply via lookandfeeltool ──────────────────────────
step "4/5" "Applying Look and Feel via lookandfeeltool..."
if command -v lookandfeeltool &>/dev/null; then
    lookandfeeltool --apply "$THEME_ID" 2>/dev/null \
      && ok "Look and Feel applied: $THEME_ID" \
      || err "lookandfeeltool apply failed"
else
    err "lookandfeeltool not found — apply manually: System Settings → Global Theme"
fi

# ── Step 5: Set wallpaper + colour scheme via plasma-apply-* ───
step "5/5" "Applying wallpaper and colour scheme..."
FIRST_WALL="$WALL_DEST/1.jpg"

# Set wallpaper via dbus (Plasma 5/6)
if command -v qdbus &>/dev/null; then
    qdbus org.kde.plasmashell /PlasmaShell \
        org.kde.PlasmaShell.evaluateScript \
        "var allDesktops = desktops(); for (var i=0; i<allDesktops.length; i++) { d=allDesktops[i]; d.wallpaperPlugin='org.kde.image'; d.currentConfigGroup=Array('Wallpaper','org.kde.image','General'); d.writeConfig('Image','file://$FIRST_WALL'); }" \
        2>/dev/null && ok "Wallpaper applied via qdbus" || true
fi

# Apply colour scheme
if command -v plasma-apply-colorscheme &>/dev/null; then
    plasma-apply-colorscheme PeakyBlinders 2>/dev/null \
      && ok "Colour scheme applied" \
      || err "plasma-apply-colorscheme failed"
fi

# Apply dark global theme
if command -v plasma-apply-lookandfeel &>/dev/null; then
    plasma-apply-lookandfeel --apply "$THEME_ID" 2>/dev/null || true
fi

echo ""
echo "  ─────────────────────────────────────────"
echo "  Installation complete!"
echo ""
echo "  To finalise in System Settings:"
echo "  → Global Theme: select 'Peaky Blinders'"
echo "  → Colors: select 'Peaky Blinders'"
echo "  → Wallpaper: Browse → $WALL_DEST"
echo ""
echo "  Wallpaper Slideshow (KDE):"
echo "  Right-click Desktop → Configure Desktop"
echo "  → Wallpaper Type: Slideshow"
echo "  → Add Folder → $WALL_DEST"
echo ""
echo -e "${GOLD}  By order of the Peaky Blinders.${NC}"
echo ""
