#!/usr/bin/env bash
# ============================================================
#  Peaky Blinders — KDE Plasma Theme Uninstaller
# ============================================================
set -euo pipefail

GOLD='\033[0;33m'; GRN='\033[0;32m'; NC='\033[0m'

echo -e "\n${GOLD}  Peaky Blinders KDE Theme — Uninstaller${NC}\n"

rm -rf "$HOME/.local/share/plasma/look-and-feel/com.peakyblinders.theme" 2>/dev/null && \
    echo -e "  ${GRN}✓${NC} Plasma Look and Feel removed" || true

rm -rf "$HOME/.local/share/wallpapers/PeakyBlinders" 2>/dev/null && \
    echo -e "  ${GRN}✓${NC} Wallpapers removed" || true

rm -f "$HOME/.local/share/color-schemes/PeakyBlinders.colors" 2>/dev/null && \
    echo -e "  ${GRN}✓${NC} Colour scheme removed" || true

# Restore Breeze Dark as default
lookandfeeltool --apply org.kde.breezedark.desktop 2>/dev/null && \
    echo -e "  ${GRN}✓${NC} Restored Breeze Dark theme" || true

echo -e "\n  Uninstall complete. Apply a new theme via System Settings → Global Theme.\n"
