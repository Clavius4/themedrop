# Peaky Blinders — macOS Theme Pack

> *"By order of the Peaky Blinders."*

A complete macOS personalisation pack inspired by the BBC series **Peaky Blinders**.
Dark, moody, and dripping in 1920s Birmingham atmosphere.

---

## What's Included

| File / Folder | Purpose |
|---|---|
| `wallpapers/` | 10 HD Peaky Blinders wallpapers (1080p+) |
| `extras/PeakyBlinders.terminal` | Terminal.app colour scheme — charcoal bg, amber/gold text |
| `install.sh` | One-command installer (wallpapers + dark mode + accent colour + Terminal) |
| `uninstall.sh` | Reverts all changes and removes wallpapers |

---

## Requirements

- macOS **Monterey 12**, **Ventura 13**, **Sonoma 14**, or **Sequoia 15**
- Terminal.app (pre-installed on all Macs)
- No third-party apps required

---

## Installation

### Option A — Automatic (Recommended)

Open **Terminal**, navigate to this folder, and run:

```bash
cd ~/Downloads/PeakyBlindersTheme-macOS
chmod +x install.sh
./install.sh
```

The script will:

1. Copy all 10 wallpapers to `~/Library/Desktop Pictures/PeakyBlinders/`
2. Set wallpaper #1 as your current desktop background
3. Enable **Dark Mode** system-wide
4. Set accent and highlight colour to **Amber / Gold**
5. Open the Terminal colour scheme for you to activate

> You may be prompted to grant Accessibility or Automation permissions the first time — click **OK** in any permission dialogs that appear.

---

### Option B — Manual (Step by Step)

#### 1. Install Wallpapers

1. Open **Finder** → Go to `~/Library/Desktop Pictures/`
   *(press ⌘+Shift+G in Finder and paste the path)*
2. Create a new folder named `PeakyBlinders`
3. Copy all `.jpg` files from `wallpapers/` into it

#### 2. Set Wallpaper & Slideshow

**macOS Ventura / Sonoma / Sequoia:**
1. Open **System Settings** → **Wallpaper**
2. Click **+** (bottom-left) → **Add Folder**
3. Navigate to `~/Library/Desktop Pictures/PeakyBlinders`
4. Set **Change picture:** to *Every Hour* (or your preference)
5. Enable **Shuffle Order** if desired

**macOS Monterey:**
1. Open **System Preferences** → **Desktop & Screen Saver**
2. Click **Desktop** tab → click **+** at the bottom-left
3. Select the `PeakyBlinders` folder

#### 3. Enable Dark Mode

**System Settings** → **Appearance** → select **Dark**

#### 4. Set Accent Colour

**System Settings** → **Appearance** → **Accent colour** → choose **Orange**

This gives the closest Peaky Blinders amber/gold feel available in macOS.

#### 5. Install Terminal Colour Scheme

1. **Double-click** `extras/PeakyBlinders.terminal`
   Terminal.app opens and imports the profile automatically.
2. Open **Terminal → Settings → Profiles**
3. Select **PeakyBlinders** in the left sidebar
4. Click **Default** (bottom-left) to set it as the default profile
5. Close and reopen Terminal to see the new look

---

## Colour Palette

| Role | Hex | Preview |
|---|---|---|
| Background | `#1A1612` | Deep charcoal |
| Default text | `#C8A96E` | Warm amber |
| Bold / bright | `#F0C040` | Gold |
| Cursor | `#F0C040` | Gold |
| Selection | `#402F1F` | Dark sepia |
| Red (ANSI) | `#C0392B` | Brick red |
| Green (ANSI) | `#7D9E6B` | Muted sage |
| Accent (macOS) | Orange | System orange |

---

## Uninstall

```bash
chmod +x uninstall.sh
./uninstall.sh
```

This removes the wallpaper folder, restores the Blue accent colour, and re-enables Light Mode.

To also remove the Terminal profile: open **Terminal → Settings → Profiles**, select **PeakyBlinders**, and click the **–** button.

---

## Wallpaper Slideshow Tips

| Setting | Recommendation |
|---|---|
| Interval | Every 30 minutes or Every Hour |
| Shuffle | On — keeps the mood fresh |
| Screen saver | Set to **Drift** or **Floating** in dark grey for a cinematic look |

---

## Troubleshooting

**"Operation not permitted" when running install.sh**
→ Go to **System Settings → Privacy & Security → Accessibility**
→ Add Terminal.app and enable it

**Accent colour didn't change after install**
→ Log out and back in (⌘ → Apple menu → Log Out)

**Wallpaper reverted after restart**
→ You need to enable the slideshow folder via System Settings (Option B → Step 2)
→ The script sets wallpaper for the current session; macOS needs the folder set in Settings to persist across reboots

**Terminal profile not showing**
→ Manually open `extras/PeakyBlinders.terminal` from Finder (right-click → Open)

---

## Credits

Wallpapers sourced from [wallpapercave.com](https://wallpapercave.com/peaky-blinders-wallpapers) for personal/non-commercial use.
Peaky Blinders is a trademark of Caryn Mandabach Productions / Tiger Aspect Productions / BBC.
This theme pack is a fan creation and is not affiliated with or endorsed by the show's creators.

---

*"He who makes a beast of himself gets rid of the pain of being a man."*
