#!/usr/bin/env bash
# ============================================================
#  Peaky Blinders macOS Theme — Installer
#  Supports: macOS Monterey 12 · Ventura 13 · Sonoma 14/15
# ============================================================

set -euo pipefail

THEME_NAME="PeakyBlinders"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
WALLPAPER_SRC="$SCRIPT_DIR/wallpapers"
WALLPAPER_DEST="$HOME/Library/Desktop Pictures/$THEME_NAME"
TERMINAL_SRC="$SCRIPT_DIR/extras/PeakyBlinders.terminal"

# ── Colours for output ────────────────────────────────────────
GOLD='\033[0;33m'
GRN='\033[0;32m'
RED='\033[0;31m'
NC='\033[0m'

step() { echo -e "${GOLD}[ $1 ]${NC} $2"; }
ok()   { echo -e "       ${GRN}✓${NC} $1"; }
err()  { echo -e "       ${RED}✗${NC} $1"; }

# ── Guard: macOS only ─────────────────────────────────────────
if [[ "$(uname)" != "Darwin" ]]; then
  echo -e "${RED}Error:${NC} This installer is for macOS only."
  exit 1
fi

echo ""
echo "  ██████╗ ███████╗ █████╗ ██╗  ██╗██╗   ██╗"
echo "  ██╔══██╗██╔════╝██╔══██╗██║ ██╔╝╚██╗ ██╔╝"
echo "  ██████╔╝█████╗  ███████║█████╔╝  ╚████╔╝ "
echo "  ██╔═══╝ ██╔══╝  ██╔══██║██╔═██╗   ╚██╔╝  "
echo "  ██║     ███████╗██║  ██║██║  ██╗   ██║   "
echo "  ╚═╝     ╚══════╝╚═╝  ╚═╝╚═╝  ╚═╝   ╚═╝   "
echo "       B L I N D E R S  —  macOS Theme"
echo "  ─────────────────────────────────────────"
echo ""

# ── Step 1: Copy wallpapers ───────────────────────────────────
step "1/5" "Installing wallpapers..."
mkdir -p "$WALLPAPER_DEST"
cp -f "$WALLPAPER_SRC"/*.jpg "$WALLPAPER_DEST/"
WALL_COUNT=$(ls "$WALLPAPER_DEST"/*.jpg 2>/dev/null | wc -l | tr -d ' ')
ok "Copied $WALL_COUNT wallpapers → $WALLPAPER_DEST"

# ── Step 2: Set wallpaper (first image) ───────────────────────
step "2/5" "Applying wallpaper..."
FIRST_WALL="$WALLPAPER_DEST/1.jpg"

osascript <<APPLESCRIPT 2>/dev/null && ok "Wallpaper applied" || err "Wallpaper apply failed (check System Settings manually)"
tell application "System Events"
    set theDesktops to every desktop
    repeat with aDesktop in theDesktops
        set picture of aDesktop to "$FIRST_WALL"
    end repeat
end tell
APPLESCRIPT

# ── Step 3: Enable Dark Mode ──────────────────────────────────
step "3/5" "Enabling Dark Mode..."
osascript -e 'tell application "System Events" to tell appearance preferences to set dark mode to true' 2>/dev/null \
  && ok "Dark Mode enabled" \
  || err "Dark Mode toggle failed (enable in System Settings → Appearance)"

# ── Step 4: Set accent & highlight colour (Orange/Gold) ───────
step "4/5" "Applying Peaky Blinders accent colour (amber/gold)..."
# AccentColor: -1=Graphite 0=Red 1=Orange 2=Yellow 3=Green 4=Blue 5=Purple 6=Pink
defaults write NSGlobalDomain AppleAccentColor -int 1 2>/dev/null \
  && ok "Accent colour → Orange" \
  || err "Accent colour change failed"

defaults write NSGlobalDomain AppleHighlightColor \
  "1.000000 0.749020 0.000000 Yellow" 2>/dev/null \
  && ok "Highlight colour → Amber/Gold" \
  || err "Highlight colour change failed"

# ── Step 5: Install Terminal profile ─────────────────────────
step "5/5" "Installing Terminal colour scheme..."
if [[ -f "$TERMINAL_SRC" ]]; then
  # Register the profile with Terminal.app
  open -a Terminal "$TERMINAL_SRC" 2>/dev/null \
    && ok "PeakyBlinders.terminal profile opened in Terminal — set it as Default in Terminal → Preferences → Profiles" \
    || err "Could not open .terminal file automatically (open it manually from extras/)"
else
  err "Terminal profile not found at $TERMINAL_SRC"
fi

# ── Slideshow setup instructions ─────────────────────────────
echo ""
echo "  ─────────────────────────────────────────"
echo "  To enable the 10-image Wallpaper Slideshow:"
echo ""
echo "  macOS Ventura / Sonoma:"
echo "    System Settings → Wallpaper"
echo "    → click  +  at bottom-left"
echo "    → Add Folder → choose:"
echo "    $WALLPAPER_DEST"
echo "    → set interval (e.g. Every Hour) + enable Shuffle"
echo ""
echo "  macOS Monterey:"
echo "    System Preferences → Desktop & Screen Saver"
echo "    → Desktop → + → choose folder above"
echo "  ─────────────────────────────────────────"
echo ""
echo -e "${GOLD}  By order of the Peaky Blinders.${NC}"
echo ""
echo "  Log out and back in for accent colour to fully take effect."
echo ""
