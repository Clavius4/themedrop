#!/usr/bin/env bash
# ============================================================
#  Peaky Blinders macOS Theme — Uninstaller
# ============================================================

set -euo pipefail

THEME_NAME="PeakyBlinders"
WALLPAPER_DEST="$HOME/Library/Desktop Pictures/$THEME_NAME"

GOLD='\033[0;33m'
GRN='\033[0;32m'
NC='\033[0m'

echo ""
echo -e "${GOLD}  Peaky Blinders Theme — Uninstaller${NC}"
echo "  ─────────────────────────────────────"

# Remove wallpapers
if [[ -d "$WALLPAPER_DEST" ]]; then
  rm -rf "$WALLPAPER_DEST"
  echo -e "  ${GRN}✓${NC} Removed wallpapers from $WALLPAPER_DEST"
else
  echo "  Wallpaper folder not found — already removed."
fi

# Restore default accent colour (Blue = 4)
defaults write NSGlobalDomain AppleAccentColor -int 4 2>/dev/null && \
  echo -e "  ${GRN}✓${NC} Accent colour restored to Blue"

defaults delete NSGlobalDomain AppleHighlightColor 2>/dev/null && \
  echo -e "  ${GRN}✓${NC} Highlight colour restored to default"

# Restore Light Mode
osascript -e 'tell application "System Events" to tell appearance preferences to set dark mode to false' 2>/dev/null && \
  echo -e "  ${GRN}✓${NC} Light Mode restored"

echo ""
echo "  Uninstall complete. Set a new wallpaper in System Settings."
echo ""
