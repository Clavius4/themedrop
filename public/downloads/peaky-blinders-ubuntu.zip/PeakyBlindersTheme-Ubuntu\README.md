# Peaky Blinders — GNOME / Ubuntu Theme Pack

> *"By order of the Peaky Blinders."*

A full GNOME personalisation pack: dark GTK 3 & 4 theme with amber/gold accents,
10-image HD wallpaper set, and GNOME background integration.

---

## What's Included

| File / Folder | Purpose |
|---|---|
| `wallpapers/` | 10 HD Peaky Blinders wallpapers |
| `theme/PeakyBlinders-GTK/` | GTK 3 + GTK 4 colour theme (charcoal + gold) |
| `gnome-backgrounds/peaky-blinders.xml` | Registers wallpapers in GNOME Settings → Background |
| `install.sh` | One-command installer |
| `uninstall.sh` | Full reverter |

---

## Compatibility

| Distro | Status |
|---|---|
| Ubuntu 22.04 LTS | Fully tested |
| Ubuntu 24.04 LTS | Fully tested |
| Debian 12 (Bookworm) | Compatible |
| Fedora 38 / 39 / 40 | Compatible |
| Pop!_OS 22.04 | Compatible |
| Linux Mint 21.x (Cinnamon) | Wallpapers only |

GNOME version required: **42 or later** (for dark mode `color-scheme` key).
GTK theme works on GNOME 40+.

---

## Installation

### Automatic

```bash
cd ~/Downloads/PeakyBlindersTheme-Ubuntu
chmod +x install.sh
./install.sh
```

This will:
1. Install GTK 3/4 theme → `~/.themes/PeakyBlinders-GTK/`
2. Copy wallpapers → `~/.themes/PeakyBlinders/wallpapers/`
3. Register wallpapers in GNOME Settings → Background
4. Apply GTK theme via `gsettings`
5. Set wallpaper #1 as current background
6. Enable Dark Mode (`prefer-dark`) and orange accent

### Manual

#### 1. GTK Theme
```bash
mkdir -p ~/.themes
cp -r theme/PeakyBlinders-GTK ~/.themes/
```
Open **GNOME Tweaks** → Appearance → Legacy Applications → **PeakyBlinders-GTK**

Install GNOME Tweaks if needed:
```bash
sudo apt install gnome-tweaks      # Ubuntu/Debian
sudo dnf install gnome-tweaks      # Fedora
```

#### 2. Wallpapers
```bash
mkdir -p ~/.themes/PeakyBlinders/wallpapers
cp wallpapers/*.jpg ~/.themes/PeakyBlinders/wallpapers/
```

#### 3. Register in GNOME Background picker
```bash
mkdir -p ~/.local/share/gnome-background-properties
# Edit the XML to replace $HOME with your actual home path, then:
cp gnome-backgrounds/peaky-blinders.xml \
   ~/.local/share/gnome-background-properties/
```

#### 4. Apply settings manually
```bash
# Dark mode
gsettings set org.gnome.desktop.interface color-scheme 'prefer-dark'

# GTK theme
gsettings set org.gnome.desktop.interface gtk-theme 'PeakyBlinders-GTK'

# Wallpaper
gsettings set org.gnome.desktop.background picture-uri \
  "file://$HOME/.themes/PeakyBlinders/wallpapers/1.jpg"
gsettings set org.gnome.desktop.background picture-uri-dark \
  "file://$HOME/.themes/PeakyBlinders/wallpapers/1.jpg"

# Ubuntu accent (23.04+)
gsettings set org.gnome.desktop.interface accent-color 'orange'
```

---

## Wallpaper Slideshow

GNOME doesn't have a built-in slideshow timer in recent versions.
**Recommended:** install **Wallpaper Slideshow** GNOME extension:
```
https://extensions.gnome.org/extension/1200/wallpaper-slideshow/
```
Then point it at `~/.themes/PeakyBlinders/wallpapers/`

---

## Colour Palette

| Role | Hex |
|---|---|
| Background | `#1A1612` deep charcoal |
| Window bg | `#211D18` dark sepia |
| Default text | `#C8A96E` warm amber |
| Bold / active | `#F0C040` bright gold |
| Accent / selection | `#C8A030` amber |
| Error | `#C0392B` brick red |

---

## Uninstall

```bash
chmod +x uninstall.sh && ./uninstall.sh
```

---

## Credits

Wallpapers from [wallpapercave.com](https://wallpapercave.com/peaky-blinders-wallpapers) — personal/non-commercial use.
Fan creation — not affiliated with the show's creators.
