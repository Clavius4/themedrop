#!/usr/bin/env bash
# ============================================================
#  Peaky Blinders — GNOME / Ubuntu Theme Installer
#  Tested: Ubuntu 22.04 LTS, 23.10, 24.04 LTS
#          Debian 12, Fedora 38+, Pop!_OS 22.04
# ============================================================

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
THEME_NAME="PeakyBlinders-GTK"
WALL_DIR="$HOME/.themes/PeakyBlinders/wallpapers"
GTK_THEME_DIR="$HOME/.themes/$THEME_NAME"
BG_PROPS_DIR="$HOME/.local/share/gnome-background-properties"

GOLD='\033[0;33m'
GRN='\033[0;32m'
RED='\033[0;31m'
NC='\033[0m'

step() { echo -e "${GOLD}[ $1 ]${NC} $2"; }
ok()   { echo -e "       ${GRN}✓${NC} $1"; }
err()  { echo -e "       ${RED}✗${NC} $1 (continuing...)"; }

# ── Guard ──────────────────────────────────────────────────────
if [[ "$(uname)" != "Linux" ]]; then
  echo -e "${RED}Error:${NC} This installer is for Linux (GNOME) only."
  exit 1
fi

if ! command -v gsettings &>/dev/null; then
  echo -e "${RED}Error:${NC} gsettings not found. Is GNOME installed?"
  exit 1
fi

echo ""
echo "  ██████╗ ███████╗ █████╗ ██╗  ██╗██╗   ██╗"
echo "  ██╔══██╗██╔════╝██╔══██╗██║ ██╔╝╚██╗ ██╔╝"
echo "  ██████╔╝█████╗  ███████║█████╔╝  ╚████╔╝ "
echo "  ██╔═══╝ ██╔══╝  ██╔══██║██╔═██╗   ╚██╔╝  "
echo "  ██║     ███████╗██║  ██║██║  ██╗   ██║   "
echo "  ╚═╝     ╚══════╝╚═╝  ╚═╝╚═╝  ╚═╝   ╚═╝   "
echo "       B L I N D E R S  —  GNOME Theme"
echo "  ─────────────────────────────────────────"
echo ""

# ── Step 1: Copy GTK theme ─────────────────────────────────────
step "1/6" "Installing GTK 3/4 theme..."
mkdir -p "$GTK_THEME_DIR"
cp -r "$SCRIPT_DIR/theme/$THEME_NAME/"* "$GTK_THEME_DIR/"
ok "GTK theme copied → $GTK_THEME_DIR"

# ── Step 2: Copy wallpapers ────────────────────────────────────
step "2/6" "Installing wallpapers..."
mkdir -p "$WALL_DIR"
cp -f "$SCRIPT_DIR/wallpapers/"*.jpg "$WALL_DIR/"
WCOUNT=$(ls "$WALL_DIR"/*.jpg 2>/dev/null | wc -l)
ok "Copied $WCOUNT wallpapers → $WALL_DIR"

# ── Step 3: Install GNOME background list ──────────────────────
step "3/6" "Registering wallpapers in GNOME backgrounds..."
mkdir -p "$BG_PROPS_DIR"
# Substitute real $HOME path into the XML (the XML uses literal path)
sed "s|\$HOME|$HOME|g" "$SCRIPT_DIR/gnome-backgrounds/peaky-blinders.xml" \
    > "$BG_PROPS_DIR/peaky-blinders.xml"
ok "Background list registered → $BG_PROPS_DIR/peaky-blinders.xml"

# ── Step 4: Apply GTK theme ────────────────────────────────────
step "4/6" "Applying GTK theme via gsettings..."
gsettings set org.gnome.desktop.interface gtk-theme "$THEME_NAME" 2>/dev/null \
  && ok "GTK theme set to $THEME_NAME" \
  || err "gtk-theme gsettings failed"

# ── Step 5: Set wallpaper ──────────────────────────────────────
step "5/6" "Setting desktop wallpaper..."
FIRST_WALL="$WALL_DIR/1.jpg"

# Try both URI styles (Wayland vs X11 / older GNOME)
gsettings set org.gnome.desktop.background picture-uri "file://$FIRST_WALL" 2>/dev/null || true
gsettings set org.gnome.desktop.background picture-uri-dark "file://$FIRST_WALL" 2>/dev/null || true
gsettings set org.gnome.desktop.background picture-options "zoom" 2>/dev/null || true
ok "Wallpaper set → $FIRST_WALL"

# ── Step 6: Dark mode + colours ────────────────────────────────
step "6/6" "Enabling Dark Mode and colour scheme..."

# Dark colour scheme (GNOME 42+)
gsettings set org.gnome.desktop.interface color-scheme 'prefer-dark' 2>/dev/null \
  && ok "Dark Mode enabled (color-scheme)" \
  || err "color-scheme key not available on this GNOME version"

# Fallback: GTK prefer dark theme (GNOME < 42)
gsettings set org.gnome.desktop.interface gtk-theme "${THEME_NAME}" 2>/dev/null || true

# Ubuntu accent colour (Ubuntu 23.04+)
if gsettings list-schemas 2>/dev/null | grep -q "org.gnome.desktop.interface"; then
  gsettings set org.gnome.desktop.interface accent-color 'orange' 2>/dev/null \
    && ok "Accent colour set to Orange" \
    || true
fi

echo ""
echo "  ─────────────────────────────────────────"
echo "  Installation complete!"
echo ""
echo "  For best results, also install:"
echo "    sudo apt install gnome-tweaks"
echo "  Then: Tweaks → Appearance → Legacy Apps → PeakyBlinders-GTK"
echo ""
echo "  Wallpaper slideshow (10 images):"
echo "  Settings → Background → select any 'Peaky Blinders' image"
echo "  The full folder is at: $WALL_DIR"
echo ""
echo "  Cursor theme (optional darker look):"
echo "    sudo apt install dmz-cursor-theme"
echo "    gsettings set org.gnome.desktop.interface cursor-theme 'DMZ-Black'"
echo ""
echo -e "${GOLD}  By order of the Peaky Blinders.${NC}"
echo ""
