#!/usr/bin/env bash
# ============================================================
#  Peaky Blinders — GNOME / Ubuntu Theme Uninstaller
# ============================================================
set -euo pipefail

GOLD='\033[0;33m'; GRN='\033[0;32m'; NC='\033[0m'

echo -e "\n${GOLD}  Peaky Blinders GNOME Theme — Uninstaller${NC}\n"

# Remove GTK theme
rm -rf "$HOME/.themes/PeakyBlinders-GTK" 2>/dev/null && \
    echo -e "  ${GRN}✓${NC} GTK theme removed" || true

# Remove wallpapers
rm -rf "$HOME/.themes/PeakyBlinders" 2>/dev/null && \
    echo -e "  ${GRN}✓${NC} Wallpapers removed" || true

# Remove background list
rm -f "$HOME/.local/share/gnome-background-properties/peaky-blinders.xml" 2>/dev/null && \
    echo -e "  ${GRN}✓${NC} GNOME background list removed" || true

# Restore defaults
gsettings reset org.gnome.desktop.interface gtk-theme 2>/dev/null && \
    echo -e "  ${GRN}✓${NC} GTK theme reset to default" || true
gsettings reset org.gnome.desktop.interface color-scheme 2>/dev/null && \
    echo -e "  ${GRN}✓${NC} Colour scheme reset to default" || true
gsettings reset org.gnome.desktop.background picture-uri 2>/dev/null || true
gsettings reset org.gnome.desktop.background picture-uri-dark 2>/dev/null || true
echo -e "  ${GRN}✓${NC} Wallpaper reset to default\n"
echo "  Uninstall complete."
